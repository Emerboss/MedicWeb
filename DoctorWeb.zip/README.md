# Asignación #1 

------------

## Proyecto FUSALMO jovenes resilientes


------------

> Crear una página web para Doctores, este debe de tener 4 páginas que estén vinculadas entre, estas son: 
- -Página de Inicio
- -Página de Servicios Médicos
- -Página de Conócenos
- -Página de Contáctanos
Estas páginas deben de tener lo siguiente:-Menú para poder desplazarse entre las páginas.
1. -En el Header debe de Logo de la empresa de los Doctores.
2. -Debe tener CSS.
3. -Llevar una estructura que cumpla con la semántica de un sitio web.
4. -Colocar Fotografías según usted crea necesario. 
5. -Contáctenos debe llevar un formulario con: 
Correo de contacto, teléfono,mensaje, botón para enviar 
# Challenge Accepte, Emerson Bonilla.
